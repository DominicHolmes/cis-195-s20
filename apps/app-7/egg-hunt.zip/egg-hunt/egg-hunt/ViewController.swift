//
//  ViewController.swift
//  egg-hunt
//
//  Created by Dominic Holmes on 4/3/20.
//  Copyright © 2020 University of Pennsylvania. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    
    @IBOutlet var mapView: MKMapView!
    @IBOutlet var countLabel: UILabel!
    
    // TODO: set up Firebase variables (ref, refHandle)

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        // TODO: set up Firebase ref
        
        // TODO: set 'refHandle' up to observe(.value) changes inside the Firebase database. Each time a change is observed, the closure will be called. Inside this closure you should:
        //    - Decode the 'snapshot' (Firebase data) into an array of NSDictionary objects
        //    - Decode the array of dictionaries into an array of EggAnnotations
        //    - Remove all existing EggAnnotations from the Map
        //    - Add the updated EggAnnoations to the Map
        //    - Update the countLabel
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        centerMapOnPennCampus()
    }
    
    // TODO: implement
    func centerMapOnPennCampus() {
        
    }
}



// MARK: MKMapViewDelegate
extension ViewController: MKMapViewDelegate {
    
    // TODO: Implement
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let identifier = "EggAnnotationIdentifier"
        guard let eggAnnotation = annotation as? EggAnnotation else { return nil }
        
        // TODO:
        // - Try to dequeue an Annotation view with the identifier
        //   - If successful, just update the annotation
        //   - If unsuccessful, make a new MKAnnotationView
        // - Configure the callout view
        //   - Customize the .image (asset is provided in Assets.xcassets)
        //   - Add a custom label (use getCalloutLabel...)
        //   - Add a custom button (use getCalloutButton...)
        
        
        // TODO: don't return nil
        return nil
    }
    
    // TODO: Implement
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 calloutAccessoryControlTapped control: UIControl) {
        
        if let button = view.rightCalloutAccessoryView as? UIButton {
            if let eggAnnotation = view.annotation as? EggAnnotation {
                
                // TODO:
                // - Toggle state of the egg annotation
                // - Update the button with the correct title
                // - Update the firebase database with the new `isCollected` value
                
            }
        }
    }
    
    
    
    // This function should not require modification
    private func getCalloutLabel(with id: EggId) -> UILabel {
        let label = UILabel()
        label.text = "Egg \(id)"
        return label
    }
    
    // This function should not require modification
    private func getCalloutButton(isCollected: Bool) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(isCollected ? "Drop" : "Collect", for: .normal)
        button.backgroundColor = .systemBlue
        button.tintColor = .white
        button.frame = CGRect.init(x: 0, y: 0, width: 100, height: 40)
        return button
    }
}
