//
//  EggAnnotation.swift
//  egg-hunt
//
//  Created by Dominic Holmes on 4/3/20.
//  Copyright © 2020 University of Pennsylvania. All rights reserved.
//

import MapKit

// Note the use of typealias to create an "EggId" type
typealias EggId = Int

/*
 You should create an EggAnnotation object for each egg in the Firebase data you receive.
 All of those EggAnnotations should be added to the mapView.
 For each EggAnnotation, the mapView will request a MKAnnotationView through its delegate method.
 EggAnnotation is the way we'll keep track of which eggs have which id, and whether or not they are "collected".
 */
class EggAnnotation: MKPointAnnotation {
    var id: EggId
    var isCollected: Bool
    
    init(coordinate: CLLocationCoordinate2D, id: EggId, isCollected: Bool) {
        self.id = id
        self.isCollected = isCollected
        super.init()
        self.coordinate = coordinate
    }
}
